package si.fri.prpo;

import java.io.Serializable;

public class Entiteta implements Serializable {

    private int id;

    public int getId(){
        return this.id;
    };

    public void setId(int id){
        this.id = id;
    }

}
