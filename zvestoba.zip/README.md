# Zvestoba
Projekt na **Fakulteti za Računalništvo in Informatiko** pri predmetu **Postopki Razvoja Programske Opreme** v 3. letniku univerzitetnega programa.

Repozitorij vsebije Maven Projekt vstvarjen znotraj IntelliJ razvojnega okolja v Java EE 8 (JDK 8u144).
Dependencies:
* kumuluzee

[WIKI](https://gitlab.prpo.li.fri.uni-lj.si/am4531/Zvestoba/wikis/home "Povezava do Wiki-ja projekta Zvestoba"), kjer si lahko ogledate razne podrobnosti in način uporabe.